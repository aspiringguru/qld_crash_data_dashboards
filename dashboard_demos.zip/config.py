PORT = 4400
DEBUG = "True"
OUTPUT_FN_CRASH_LOCATIONS_CRASH_SEVERITY = "crash_locations_years_post_codes_Crash_Severity_summary.pkl"
OUTPUT_FN_CRASH_LOCATIONS_VEHICLE_TYPE_YEAR_POSTCODE = "crash_locations_vehicle_type_year_postcode_sums.pkl"
OUTPUT_FN_ALCOHOL_SPEED_FATIGUE_DEFECT = "crash_data_queensland_e_alcohol_speed_fatigue_defect.pkl"
